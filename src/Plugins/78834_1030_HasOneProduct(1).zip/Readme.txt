1. 'Nop.Plugin.DiscountRules.HasOneProduct' directory contains source code.
2. 'DiscountRules.HasOneProduct' contains binaries. Just drop it into \Plugins directory on your server.